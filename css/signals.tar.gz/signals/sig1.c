#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
 
void handler(int sig)
{
	fprintf (stderr,"\nSignal %d received.\n");
	exit(1);
}
 
int main (int argc, char *argv[])
{
	struct sigaction act;
 
	memset (&act, '\0', sizeof(act));
	act.sa_handler = handler;
 
	if (sigaction(SIGTERM, &act, NULL) < 0) {
		perror ("sigaction");
		return 1;
	}
 
	while (1)
		sleep (10);
 
	return 0;
}
/*
Usage: 
(1) open another terminal and type ps u to view the user processes and teir PIDs
(2) find the the PID of this program (say 2344)
(3) send a SIGTERM siganl to the program using the kill command:	kill -s TERM 2344
*/
