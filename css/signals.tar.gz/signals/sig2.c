#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
 
void handler(int sig)
{
	fprintf (stderr,"\nSignal %d received.\n");
	exit(1);
}

char buf[100]="\0";
int main (int argc, char *argv[])
{
	int n;
	struct sigaction act;
	act.sa_handler = handler;
 
	if (sigaction(SIGALRM, &act, NULL) < 0) {
		perror ("sigaction");

		return 1;
	}
 	fprintf(stderr,"Enter a file name: ");
	alarm(5);
	n=read(0,buf,sizeof(buf));
	if(n>1)
		fprintf(stderr, "Filename: %s\n",buf);
	exit(0);
}
/*
wait 5 seconds for the user to enter a file name. 
If within 5 seconds the user did not enter a file name, a SIGALRM signal is sent to the process and handeled by the handler.
*/
