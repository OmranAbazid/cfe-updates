#include <stdio.h>
#include <signal.h>
 
void tstp_handler(int signo);
void int_handler(int signo);

int main (void)
{
	struct sigaction act1,act2,act3;
	act1.sa_handler = tstp_handler;
 	act2.sa_handler = int_handler;
	act3.sa_handler = SIG_IGN;

	sigaction(SIGTSTP, &act1, NULL);
	sigaction(SIGINT, &act2, NULL);
	sigaction(SIGQUIT, &act3, NULL);


 	fprintf(stderr,"Press any: [Ctrl-z], [Ctrl-q], [Ctrl-c]\n");
	for(;;)
		pause();
	exit(0);
}

void tstp_handler(int signo){
	fprintf(stderr, "Can't stop this program\n");
}
void int_handler(int signo){
	exit(0);
}

/*
Ctrl-\ 	:ignored 
Ctrl-z	:display a message "Can't stop this program"
Ctrl-c	:quit the program
*/
