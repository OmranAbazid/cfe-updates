/* sig4.c --- Example of how 2 processes can talk */
/* to each other using kill() and signal() */
/* We will fork() 2 process and let the parent send a few */
/* signals to it`s child  */


#include <stdio.h>
#include <signal.h>

void sighup(int signo); 
void sigint(int signo);
void sigquit(int signo);

main()
{ int pid;

  /* get child process */
  
   if ((pid = fork()) < 0) {
        perror("fork");
        exit(1);
    }
    
   if (pid == 0)
     { /* child */
	struct sigaction act1,act2,act3;
	act1.sa_handler = sighup;
 	act2.sa_handler = sigint;
	act3.sa_handler = sigquit;

	sigaction(SIGHUP, &act1, NULL);
	sigaction(SIGINT, &act2, NULL);
	sigaction(SIGQUIT, &act3, NULL);
	while(1);
     }
  else /* parent */
     {  /* pid hold id of child */
	sleep(3);
    	printf("\nPARENT: sending SIGHUP to child %d\n\n",pid);
     	kill(pid,SIGHUP);
        sleep(3); 
        printf("\nPARENT: sending SIGINT to child %d\n\n",pid);
        kill(pid,SIGINT);
        sleep(3);
        printf("\nPARENT: sending SIGQUIT to child %d\n\n",pid);
        kill(pid,SIGQUIT);
        sleep(3);
	exit(0);
     }
	return 0;
}

void sighup(int signo)

{ // signal(SIGHUP,sighup); /* reset signal */
	char buf[] = "SIGHUP signal caught!!\n";
	int wr = strlen(buf);
	write(1, buf, wr);

 //  fprintf(stderr,"CHILD: I have received a SIGHUP\n");
}

void sigint(int signo)

{  //signal(SIGINT,sigint); /* reset signal */
   printf("CHILD: I have received a SIGINT\n");
}

void sigquit(int signo)

{ 
 	printf("");printf("My DADDY has Killed me!!!\n");
  	exit(1);
}

