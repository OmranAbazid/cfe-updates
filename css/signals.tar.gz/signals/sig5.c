#include <stdio.h>
#include <signal.h>
 
void tstp_handler(int signo);

int main (void)
{
	signal(SIGTSTP,tstp_handler);
	signal(SIGQUIT, SIG_IGN);
	signal(SIGINT,SIG_DFL);

 	fprintf(stderr,"Press any: [Ctrl-z] or [Ctrl-q] or [Ctrl-c]\n");
	for(;;)
		pause();
	exit(0);
}

void tstp_handler(int signo){
	signal(SIGTSTP,tstp_handler);
	fprintf(stderr, "Can't stop this program\n");
}

