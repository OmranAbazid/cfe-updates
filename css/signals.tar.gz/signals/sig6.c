/*  Example of how 2 processes can talk */

#include <stdio.h>
#include <signal.h>

void tstp_handler(int signo); 
void int_handler(int signo);
void quit_handler(int signo);

main(){ 
   int pid;
   if ((pid = fork()) < 0) {
        perror("fork");
        exit(1);
    } 
   if (pid == 0){ /* child */
	signal(SIGTSTP,tstp_handler);
	signal(SIGQUIT, quit_handler);
	signal(SIGINT, int_handler);
	while(1);
     }
  else{/* parent. The pid hold id of child */
	sleep(3);
    	printf("\nPARENT: sending SIGTSTP to child %d\n\n",pid);
     	kill(pid,SIGTSTP);
        sleep(3); 
        printf("\nPARENT: sending SIGINT to child %d\n\n",pid);
        kill(pid,SIGINT);
        sleep(3);
        printf("\nPARENT: sending SIGQUIT to child %d\n\n",pid);
        kill(pid,SIGQUIT);
        sleep(3);
	exit(0);
     }
	return 0;
}

void tstp_handler(int signo){ 	
	signal(SIGTSTP,tstp_handler); /* reset signal */
	fprintf(stderr,"CHILD: I have received a SIGTSTP\n");
}

void int_handler(int signo){  
	signal(SIGINT,int_handler); /* reset signal */
   	printf("CHILD: I have received a SIGINT. Still alive ...\n");
}

void quit_handler(int signo){ 
	signal(SIGQUIT, quit_handler);
 	printf("CHILD: My DADDY has Killed me!!!\n");
  	exit(1);
}

