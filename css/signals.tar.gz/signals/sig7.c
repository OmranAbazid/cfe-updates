#include <unistd.h>
#include <signal.h>
#include <stdio.h>

int main() 
{
	int child_pid, i;
	child_pid = fork();

	if (child_pid == 0)
	{	
		/* the child process */
		signal(SIGINT, SIG_IGN);
		for (i = 1;  i <= 20000000;  i++)
		{
			if (i % 100 == 0)
			   printf("I'm still alive.\n");
		}
		printf("All done! Nobody dare to stop me! \n");
	}    
	
	else
	{
		/* the parent process */
		/* wait for 1 second to so that the child is executed first */    
		sleep(1);	
		printf("Parent will send a Dispatch to terminate Child ...\n");
		/* send SIGINT to the child process */    
		kill(child_pid, SIGINT);	
		printf("Dispatched\n");
    	}
	return 0;
}

